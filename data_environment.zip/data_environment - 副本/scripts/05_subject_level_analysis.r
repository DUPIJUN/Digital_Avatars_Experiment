library(tidyverse)
library(lmerTest)
library(performance)
library(effectsize)
library(partR2)

# 交叉聚合：计算每个被试在 4 种组合下的平均表现
subject_agg_data <- exp_data %>%
  mutate(
    intensity_num = case_when(
      INTENSITY == "NEUTRAL" ~ 1,
      INTENSITY == "LOW" ~ 2,
      INTENSITY == "HIGH" ~ 3
    )
  ) %>%
  group_by(participant, AVATAR_SEX, AVATAR_AGE) %>%
  summarise(
    m_pain = mean(pain_score, na.rm = TRUE),    # 疼痛感知
    m_help = mean(help_score, na.rm = TRUE),    # 帮助行为/意愿
    m_intensity = mean(intensity_num, na.rm = TRUE),
    .groups = "drop"
  )

#证明假设1：数字形象的年龄对个体的疼痛感知与亲社会行为具有显著影响
#证明假设2：数字形象的性别对个体的疼痛感知与亲社会行为具有显著影响
#证明假设3：数字形象的年龄与性别在疼痛感知与亲社会行为上存在显著交互作用

# 检验疼痛感知 (M1)
model_pain <- lmer(m_pain ~ AVATAR_AGE * AVATAR_SEX + (1 | participant), data = subject_agg_data)
message("--- 假设 1, 2, 3 检验结果 (因变量: 疼痛感知) ---")
print(anova(model_pain))

# 检验帮助行为 (Y)
model_help <- lmer(m_help ~ AVATAR_AGE * AVATAR_SEX + (1 | participant), data = subject_agg_data)
message("\n--- 假设 1, 2, 3 检验结果 (因变量: 帮助行为) ---")
print(anova(model_help))

#证明假设4：个体对数字形象疼痛强度的感知与其提供帮助的水平呈显著正相关

# 假设 4：感知疼痛预测帮助行为 (288行数据)
# 使用线性混合模型，排除 X，直接看 M -> Y
model_h4 <- lmer(m_help ~ m_pain + (1 | participant), data = subject_agg_data)

summary(model_h4) # 查看 m_pain 的 Estimate 和 p 值
summary(model_pain)
summary(model_help)
library(effectsize)
eta_squared(model_pain, partial = TRUE)
eta_squared(model_help, partial = TRUE)

partR2(model_pain, partvars = "AVATAR_AGE")

r2(model_help, iterations = 5000)
r2(model_pain, iterations = 5000)

