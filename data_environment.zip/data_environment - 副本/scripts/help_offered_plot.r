# ==========================================
# 心理学毕设：2x2 交互作用图（性别+边框修复终版）
# ==========================================

library(ggplot2)
library(dplyr)

# ==========================================
# 1. 数据处理
# ==========================================

subject_agg_data <- exp_data %>%
  filter(!is.na(AVATAR_SEX), !is.na(AVATAR_AGE)) %>%
  group_by(participant, AVATAR_SEX, AVATAR_AGE) %>%
  summarise(
    m_pain = mean(pain_score, na.rm = TRUE),
    m_help = mean(help_score, na.rm = TRUE),
    .groups = "drop"
  )

# ✔ 固定因子顺序（防止颜色错位）
subject_agg_data$AVATAR_SEX <- factor(subject_agg_data$AVATAR_SEX,
                                      levels = c("MALE", "FEMALE"))

subject_agg_data$AVATAR_AGE <- factor(subject_agg_data$AVATAR_AGE,
                                      levels = c("YOUNG", "OLD"))

# ==========================================
# 2. 字体
# ==========================================

windowsFonts(
  RSong = windowsFont("SimSun"),
  RTime = windowsFont("Times New Roman")
)

# ==========================================
# 3. 绘图（✔ 已加边框）
# ==========================================

# ==========================================
# 3. 绘图（✔ 已加边框）
# ==========================================

p_base <- ggplot(subject_agg_data,
                 aes(x = AVATAR_AGE,
                     y = m_help,
                     fill = AVATAR_SEX)) +

  stat_summary(
    fun = mean,
    geom = "bar",
    position = position_dodge(0.9),
    width = 0.75,
    color = "black",
    linewidth = 0.6
  ) +

  stat_summary(
    fun.data = mean_se,
    geom = "errorbar",
    position = position_dodge(0.9),
    width = 0.15,
    size = 0.5,
    linewidth = 0.8,
    alpha = 1
  ) +

  scale_fill_manual(
    values = c("MALE" = "grey20",
               "FEMALE" = "grey80"),
    breaks = c("MALE", "FEMALE"),
    labels = c("男性", "女性")
  ) +

  scale_x_discrete(labels = c(
    "YOUNG" = "年轻",
    "OLD"   = "老年"
  )) +

  # ==========================================
  # ✔ 关键修改：只改“显示范围”，不改数据
  # ==========================================
  coord_cartesian(ylim = c(25, 55)) +

  scale_y_continuous(
    breaks = seq(25, 55, 5),
    expand = c(0, 0)
  ) +

  labs(
    x = "数字形象年龄",
    y = "帮助意愿(25–55)",
    fill = "数字形象性别"
  ) +

  theme_classic(base_size = 15) +

  theme(
    text = element_text(family = "RSong", color = "black"),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12),

    legend.position = c(0.95, 0.95),
    legend.justification = c("right", "top"),
    legend.background = element_blank(),
    legend.key = element_blank(),

    axis.line = element_line(linewidth = 0.8)
  ) 

# 调整右上角角标
theme_legend <- theme(
  legend.title = element_text(size = 14, family = "RSong"),
  legend.text  = element_text(size = 13, family = "RSong"),
  legend.key.size = unit(0.8, "cm"),
  legend.background = element_blank(),
  legend.key = element_blank()
)
# ==========================================
# 4. 显著性标注（完全不动）
# ==========================================

p_final_with_hooks <- p_base + theme_legend +

  annotate("segment", x = 0.77, xend = 1.77, y = 38, yend = 38, size = 0.6) +
  annotate("segment", x = 0.77, xend = 0.77, y = 38, yend = 37.5, size = 0.6) +
  annotate("segment", x = 1.77, xend = 1.77, y = 38, yend = 37.5, size = 0.6) +
  annotate("text", x = 1.27, y = 38.3, label = "**", size = 7) +

  annotate("segment", x = 1.23, xend = 2.23, y = 39.5, yend = 39.5, size = 0.6) +
  annotate("segment", x = 1.23, xend = 1.23, y = 39.5, yend = 39, size = 0.6) +
  annotate("segment", x = 2.23, xend = 2.23, y = 39.5, yend = 39, size = 0.6) +
  annotate("text", x = 1.73, y = 39.8, label = "**", size = 7)

# ==========================================
# 5. 输出
# ==========================================

print(p_final_with_hooks)

ggsave(
  "Figure_Help_Behavior_Final.png",
  plot = p_final_with_hooks,
  width = 8.5,
  height = 5.5,
  dpi = 600
)