library(tidyverse)
library(lme4)
library(lmerTest)
library(dplyr)

# 交叉聚合：计算每个被试在 4 种组合下的平均表现
# 读取数据
exp_data <- read.csv("./data_cleaned/merged_data.csv")
subject_agg_data <- exp_data %>%
  mutate(
    intensity_num = case_when(
      INTENSITY == "NEUTRAL" ~ 1,
      INTENSITY == "LOW" ~ 2,
      INTENSITY == "HIGH" ~ 3
    )
  ) %>%
  group_by(participant, AVATAR_SEX, AVATAR_AGE) %>%
  summarise(
    m_pain = mean(pain_score, na.rm = TRUE),    # 疼痛感知
    m_help = mean(help_score, na.rm = TRUE),    # 帮助行为/意愿
    m_intensity = mean(intensity_num, na.rm = TRUE),
    .groups = "drop"
  )

merged_data <- subject_agg_data %>%
  left_join(iri_processed, by = "participant")
#证明假设1：数字形象的年龄对个体的疼痛感知与亲社会行为具有显著影响
#证明假设2：数字形象的性别对个体的疼痛感知与亲会行为具有显著影响
#证明假设3：数字形象的年龄与性别在疼痛感知与亲社会行为上存在显著交互作用

# 检验疼痛感知 (M1)
model_pain <- lmer(m_pain ~ AVATAR_AGE * AVATAR_SEX + (1 | participant), data = subject_agg_data)
message("--- 假设 1, 2, 3 检验结果 (因变量: 疼痛感知) ---")
print(anova(model_pain))

# 检验帮助行为 (Y)
model_help <- lmer(m_help ~ AVATAR_AGE * AVATAR_SEX + (1 | participant), data = subject_agg_data)
message("\n--- 假设 1, 2, 3 检验结果 (因变量: 帮助行为) ---")
print(anova(model_help))

#证明假设4：个体对数字形象疼痛强度的感知与其提供帮助的水平呈显著正相关

# 假设 4：感知疼痛预测帮助行为 (288行数据)
# 使用线性混合模型，排除 X，直接看 M -> Y

IRI_model_help <- lmer(
  m_help ~ AVATAR_AGE * AVATAR_SEX + IRI_total + (1 | participant),
  data = merged_data
)

IRI_model_pain <- lmer(
  m_pain ~ AVATAR_AGE * AVATAR_SEX + IRI_total + (1 | participant),
  data = merged_data
)

summary(IRI_model_help)
summary(IRI_model_pain)

library(effectsize)
eta_squared(IRI_model_pain, partial = TRUE)
eta_squared(IRI_model_help, partial = TRUE)

library(partR2)
partR2(IRI_model_pain, partvars = "AVATAR_AGE")

library(performance)

r2(IRI_model_help, iterations = 5000)
r2(IRI_model_pain, iterations = 5000)

# 检验 IRI 是否调节【疼痛感知 -> 帮助行为】的关系
IRI_moderation_model <- lmer(
  m_help ~ m_pain * IRI_total + (1 | participant), 
  data = merged_data
)
summary(IRI_moderation_model)

# 中心化代码示例
merged_data$m_pain_c <- scale(merged_data$m_pain, scale = FALSE)
merged_data$IRI_total_c <- scale(merged_data$IRI_total, scale = FALSE)

# 重新跑模型
IRI_mod_model_centered <- lmer(
  m_help ~ m_pain_c * IRI_total_c + (1 | participant), 
  data = merged_data
)
summary(IRI_mod_model_centered)
# 需要安装 performance 包
performance::model_performance(IRI_mod_model_centered)

model_extra <- lmer(m_help ~ m_pain_c * IRI_total_c + (1 + m_pain_c | participant), data = merged_data)
summary(model_extra)