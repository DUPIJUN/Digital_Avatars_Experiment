# ==============================
# 0. 加载包
# ==============================
library(tidyverse)
library(lme4)
library(lmerTest)
library(effectsize)
library(performance)
library(partR2)

# ==============================
# 1. 数据整理（被试层聚合）
# ==============================
subject_agg_data <- exp_data %>%
  mutate(
    intensity_num = case_when(
      INTENSITY == "NEUTRAL" ~ 1,
      INTENSITY == "LOW" ~ 2,
      INTENSITY == "HIGH" ~ 3
    )
  ) %>%
  group_by(participant, AVATAR_SEX, AVATAR_AGE) %>%
  summarise(
    m_pain = mean(pain_score, na.rm = TRUE),
    m_help = mean(help_score, na.rm = TRUE),
    m_intensity = mean(intensity_num, na.rm = TRUE),
    .groups = "drop"
  )

# ==============================
# 2. ⭐ 合并 IRI（关键修复点）
# ==============================
subject_agg_data <- subject_agg_data %>%
  left_join(iri_processed, by = "participant")

# ==============================
# 3. 中心化变量（标准做法）
# ==============================
subject_agg_data <- subject_agg_data %>%
  mutate(
    m_pain_c = scale(m_pain, scale = FALSE),
    m_help_c = scale(m_help, scale = FALSE),
    IRI_total_c = scale(IRI_total, scale = FALSE)
  )

# ==============================
# 4. H1–H3：刺激效应模型
# ==============================

# 疼痛感知模型
model_pain <- lmer(
  m_pain ~ AVATAR_AGE * AVATAR_SEX + (1 | participant),
  data = subject_agg_data
)

anova(model_pain)

# 帮助行为模型
model_help <- lmer(
  m_help ~ AVATAR_AGE * AVATAR_SEX + (1 | participant),
  data = subject_agg_data
)

anova(model_help)

# ==============================
# 5. H4：疼痛 → 帮助（主效应）
# ==============================
model_h4 <- lmer(
  m_help_c ~ m_pain_c + (1 | participant),
  data = subject_agg_data
)

summary(model_h4)

# ==============================
# 6. H5：共情调节模型（核心）
# ==============================
model_h5 <- lmer(
  m_help_c ~ m_pain_c * IRI_total_c + (1 | participant),
  data = subject_agg_data
)

summary(model_h5)

# ==============================
# 7. 效应量（Eta squared）
# ==============================
eta_squared(model_pain, partial = TRUE)
eta_squared(model_help, partial = TRUE)

# ==============================
# 7.5 ICC（组内相关系数）
# ==============================
library(performance)

# 疼痛感知的ICC
icc_pain <- icc(model_pain)
print("ICC - Pain Model")
print(icc_pain)

# 帮助行为的ICC
icc_help <- icc(model_help)
print("ICC - Help Model")
print(icc_help)

# 共情调节模型的ICC（可选）
icc_h5 <- icc(model_h5)
print("ICC - H5 Model")
print(icc_h5)
# ==============================
# 8. R²（模型解释力）
# ==============================
r2(model_pain, iterations = 5000)
r2(model_help, iterations = 5000)
r2(model_h5, iterations = 5000)

# ==============================
# 9. 结构贡献（可选）
# ==============================
partR2(model_pain, partvars = "AVATAR_AGE")