library(lme4)
library(dplyr)

# 创建预测网格
newdat <- expand.grid(
  m_pain_c = seq(min(merged_data$m_pain_c),
                 max(merged_data$m_pain_c),
                 length.out = 100),
  IRI_total_c = c(
    mean(merged_data$IRI_total_c) - sd(merged_data$IRI_total_c),
    mean(merged_data$IRI_total_c) + sd(merged_data$IRI_total_c)
  )
)

# 预测值
newdat$pred <- predict(
  IRI_mod_model_centered,
  newdata = newdat,
  re.form = NA
)

# 标记组别
newdat$group <- factor(newdat$IRI_total_c,
                       labels = c("低共情（-1 SD）", "高共情（+1 SD）"))

library(ggplot2)

final_plot <- ggplot(newdat, aes(x = m_pain_c, y = pred, linetype = group)) +
  
  geom_line(size = 1, color = "black") +
  
  theme_classic(base_size = 12) +
  
  labs(
    x = "感知疼痛（中心化）",
    y = "帮助意愿",
    linetype = "共情水平"
  ) +
  
  scale_linetype_manual(
    values = c("dashed", "solid")
  ) +
  
  theme(
    legend.position = "top",
    legend.title = element_blank(),
    axis.line = element_line(linewidth = 0.6),
    panel.grid = element_blank()
  )

print(final_plot)

ggsave(
  "Figure_APA_interaction.tiff",
  final_plot,
  width = 3.5,
  height = 3,
  dpi = 600
)

ggsave(
  "Figure_APA_interaction.pdf",
  final_plot,
  width = 8,
  height = 6
)

slopes <- sim_slopes(
  IRI_mod_model_centered,
  pred = m_pain_c,
  modx = IRI_total_c,
  modx.values = "plus-minus"
)

slopes$slopes