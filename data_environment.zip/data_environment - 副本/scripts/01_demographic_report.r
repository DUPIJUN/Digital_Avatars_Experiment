# 1. 加载必要的包
if (!require("readxl")) install.packages("readxl")
library(readxl)
library(tidyverse)
library(psych)

# 2. 读取已经补全性别的 Excel 文件
# 确保文件名与本地文件一致
demo_df <- read_excel("data_raw/demographic_data_origin.xlsx")

# 3. 将分类变量转换为因子（Factor），方便 R 进行统计
demo_df <- demo_df |>
  mutate(
    gender = factor(gender, levels = c('male', 'female'), labels = c("male", "female")),
    grade = factor(grade, levels = 1:4, labels = c("大一", "大二", "大三", "大四")),
    major = as.factor(major),
    vision = factor(vision, levels = c(0, 1), labels = c("正常", "矫正正常"))
  )

# --- 4. 正式开始分析 ---

# A. 连续变量分析：年龄 (Age)
message("被试年龄描述统计结果：")
age_stats <- describe(demo_df$age)
print(age_stats)

# B. 分类变量分析：频数与百分比
message("\n被试性别分布：")
gender_tab <- table(demo_df$gender)
print(gender_tab)
print(prop.table(gender_tab) * 100) # 显示百分比

message("\n被试年级分布：")
print(table(demo_df$grade))

message("\n被试专业分布：")
print(table(demo_df$major))

message("\n被试视力情况：")
print(table(demo_df$vision))

# C. 验证性检查
# 确保没有疼痛史和实验经验的异常值
message("\n排除标准检查：")
message("疼痛史人数：", sum(demo_df$pain_history == 1))
message("有实验经验人数：", sum(demo_df$exp_experience == 1))