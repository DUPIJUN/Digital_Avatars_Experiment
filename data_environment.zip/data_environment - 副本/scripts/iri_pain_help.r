library(tidyverse)
library(Hmisc)
library(gtools)

# 1. 聚合实验数据：计算每个被试在所有条件下的平均表现
# 确保得到 72 行数据，与 IRI 被试一一对应
subject_avg_performance <- subject_agg_data %>%
  group_by(participant) %>%
  summarise(
    Mean_Pain = mean(m_pain, na.rm = TRUE),
    Mean_Help = mean(m_help, na.rm = TRUE),
    .groups = "drop"
  )

# 2. 准备带有 ID 的 IRI 分数 (基于你之前的 df_clean)
# 假设 raw_data 或 df 中有 participant 这一列
iri_scores_final <- df_clean %>%
  mutate(participant = iri_data$participant) %>% # 找回被试编号
  dplyr::select(participant, PT, FS, EC, PD, Total_IRI)

# 3. 合并数据：实验表现 + IRI 特质
final_analysis_data <- subject_avg_performance %>%
  left_join(iri_scores_final, by = "participant") %>%
  dplyr::select(Mean_Pain, Mean_Help, PT, FS, EC, PD, Total_IRI)

# 4. 计算 Pearson 相关及显著性
res_final <- rcorr(as.matrix(final_analysis_data), type = "pearson")

# 5. 格式化输出：系数 + 星号 (APA/Nature 汇报风格)
r_matrix <- res_final$r
p_matrix <- res_final$P
stars <- gtools::stars.pval(p_matrix)

# 拼接结果
output_table <- matrix(paste(format(round(r_matrix, 3), nsmall = 3), stars), 
                       ncol = ncol(r_matrix))
diag(output_table) <- "-"
rownames(output_table) <- colnames(r_matrix)
colnames(output_table) <- colnames(r_matrix)

# 6. 打印最终结果
cat("\n--- 实验表现与 IRI 特质共情相关矩阵 ---\n")
print(as.data.frame(output_table))