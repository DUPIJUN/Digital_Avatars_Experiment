library(ggplot2)
library(dplyr)

# ==========================================
# 1. 字体与环境准备
# ==========================================

windowsFonts(
  RSong = windowsFont("SimSun"),
  RTime = windowsFont("Times New Roman")
)

# ==========================================
# ✔ 因子顺序锁定
# ==========================================

subject_agg_data$AVATAR_AGE <- factor(
  subject_agg_data$AVATAR_AGE,
  levels = c("YOUNG", "OLD")
)

subject_agg_data$AVATAR_SEX <- factor(
  subject_agg_data$AVATAR_SEX,
  levels = c("MALE", "FEMALE")
)

# ==========================================
# 2. 均值 + SE
# ==========================================

plot_data <- subject_agg_data %>%
  group_by(AVATAR_AGE, AVATAR_SEX) %>%
  summarise(
    mean_pain = mean(m_pain, na.rm = TRUE),
    sd_pain   = sd(m_pain, na.rm = TRUE),
    n = n(),
    se_pain = sd_pain / sqrt(n),
    .groups = "drop"
  )

# ==========================================
# 3. 绘图（核心修复）
# ==========================================

p2_pain <- ggplot(plot_data,
                  aes(x = AVATAR_AGE,
                      y = mean_pain,
                      fill = AVATAR_SEX)) +

  geom_col(
    position = position_dodge(0.9),
    width = 0.75,
    color = "black",
    linewidth = 0.6
  ) +

  geom_errorbar(
    aes(ymin = mean_pain - se_pain,
        ymax = mean_pain + se_pain),
    position = position_dodge(0.9),
    width = 0.15,
    linewidth = 0.9
  ) +

  scale_fill_manual(
    values = c("MALE" = "grey20", "FEMALE" = "grey80"),
    breaks = c("MALE", "FEMALE"),
    labels = c("男性", "女性")
  ) +

  scale_x_discrete(labels = c(
    "YOUNG" = "年轻",
    "OLD"   = "老年"
  )) +

  scale_y_continuous(
    breaks = seq(30, 60, 5),
    expand = c(0, 0)
  ) +

  # ⭐关键：只裁剪显示范围，不破坏数据
  coord_cartesian(ylim = c(30, 60)) +

  labs(
    x = "数字形象年龄",
    y = "感知疼痛(30–60)",
    fill = "数字形象性别"
  ) +

  theme_classic() +

  theme(
    text = element_text(family = "RSong", color = "black"),

    axis.title = element_text(family = "RTime", size = 15),
    axis.text = element_text(family = "RSong", size = 13, color = "black"),

    legend.position = c(0.95, 0.92),
    legend.justification = c("right", "top"),
    legend.background = element_blank(),
    legend.key = element_blank(),

    axis.line = element_line(linewidth = 0.8, color = "black")
  )

# 调整右上角角标
theme_legend <- theme(
  legend.title = element_text(size = 14, family = "RSong"),
  legend.text  = element_text(size = 13, family = "RSong"),
  legend.key.size = unit(0.8, "cm"),
  legend.background = element_blank(),
  legend.key = element_blank()
)
# ==========================================
# 4. 显著性标注（不改你原逻辑）
# ==========================================

p2_pain_final <- p2_pain + theme_legend +

  annotate("segment", x = 0.77, xend = 1.77, y = 46.5, yend = 46.5, size = 0.6) +
  annotate("segment", x = 0.77, xend = 0.77, y = 46.5, yend = 46, size = 0.6) +
  annotate("segment", x = 1.77, xend = 1.77, y = 46.5, yend = 46, size = 0.6) +
  annotate("text", x = 1.27, y = 47, label = "***", size = 7, family = "RTime") +

  annotate("segment", x = 1.23, xend = 2.23, y = 48.5, yend = 48.5, size = 0.6) +
  annotate("segment", x = 1.23, xend = 1.23, y = 48.5, yend = 48, size = 0.6) +
  annotate("segment", x = 2.23, xend = 2.23, y = 48.5, yend = 48, size = 0.6) +
  annotate("text", x = 1.73, y = 49, label = "***", size = 7, family = "RTime")

# ==========================================
# 5. 输出
# ==========================================

print(p2_pain_final)

ggsave(
  "Figure2_Pain_Perception_25to60.png",
  plot = p2_pain_final,
  width = 8.5,
  height = 5.5,
  dpi = 600
)