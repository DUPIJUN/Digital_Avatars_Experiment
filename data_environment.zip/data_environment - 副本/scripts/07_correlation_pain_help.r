library(ggplot2)
library(ggpubr) # 用于自动添加相关系数

# 执行 Pearson 相关分析
cor_results <- cor.test(subject_agg_data$m_pain, subject_agg_data$m_help)

# 打印结果
cat("--- 相关分析结果 ---\n")
print(cor_results)

# 提取关键数值用于论文写作
cat("\n相关系数 r =", round(cor_results$estimate, 3), "\n")
cat("显著性 p =", format.pval(cor_results$p.value, digits = 3), "\n")
# 1. 字体配置
windowsFonts(RSong = windowsFont("SimSun"), RTime = windowsFont("Times New Roman"))

# 2. 绘图：x轴为感知疼痛，y轴为帮助意愿
p4_nature <- ggplot(subject_agg_data, aes(x = m_pain, y = m_help)) +
  # 散点：使用半透明圆点，避免数据重叠看不清
  geom_point(color = "#3C5488B2", alpha = 0.6, size = 2.5) + # Nature常用的深蓝色
  # 线性拟合线：带阴影（置信区间）
  geom_smooth(method = "lm", color = "#E64B35FF", fill = "#E64B351A", size = 1.2) + # Nature常用的红色
  # 自动添加相关系数 r 和 p 值 (stat_cor 是 ggpubr 的功能)
  stat_cor(method = "pearson", 
           label.x = 10, label.y = 60, 
           family = "RTime", size = 5,
           aes(label = paste(..r.label.., ..p.label.., sep = "~`,`~"))) +
  # 坐标轴范围与刻度
  scale_x_continuous(limits = c(0, 75), breaks = seq(0, 70, 10)) +
  scale_y_continuous(limits = c(0, 65), breaks = seq(0, 60, 10)) +
  # 标签
  labs(x = "感知疼痛强度", 
       y = "帮助意愿",
       title = "感知疼痛与帮助意愿的相关性") +
  # Nature 极简风格主题
  theme_bw() + 
  theme(
    panel.grid.major = element_blank(), # 去掉网格线
    panel.grid.minor = element_blank(),
    panel.border = element_rect(size = 1.2, color = "black"), # 只要黑框
    text = element_text(family = "RSong"),
    axis.title = element_text(family = "RTime", size = 14, face = "bold"),
    axis.text = element_text(family = "RTime", size = 12, color = "black"),
    plot.title = element_text(family = "RTime", size = 16, face = "bold", hjust = 0.5)
  )

# 3. 预览并保存
print(p4_nature)

ggsave("Figure4_Correlation_Nature_Style.png", 
       plot = p4_nature, 
       width = 7, height = 6, dpi = 600)