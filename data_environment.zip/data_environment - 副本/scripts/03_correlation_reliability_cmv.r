# 1. 载入核心包
if (!require(psych)) install.packages("psych")
if (!require(Hmisc)) install.packages("Hmisc")
library(psych)
library(Hmisc)
library(readxl)
library(tidyverse)

# 2. 导入数据 (假设你的数据已存为 "iri_data.csv")
# 请确保 CSV 文件中包含 ID, Gender, Trait 以及 Q1-Q22 列
df <- read_excel("data_raw/IRI_origin.xlsx")
iri_data <- df
# 2. 数据清洗与反向计分处理
# 提取 Q1-Q22 题目列
items <- paste0("Q", 1:22)
ID <- paste0("participant")
df_clean <- iri_data[, c(items, ID)]

# 计分规则：2, 5, 10, 11, 14 题为反向计分 [cite: 6]
# 采用 0-4 分 5 点计分制，反向公式为 4 - 原始分 [cite: 2, 4]
rev_items <- c("Q2", "Q5", "Q10", "Q11", "Q14")
df_clean[rev_items] <- 4 - df_clean[rev_items]

# 3. 维度总分计算 
# 观点采择 (PT): 测量个体自发采纳他人观点的倾向 [cite: 2]
df_clean$PT <- rowSums(df_clean[, c("Q6", "Q9", "Q15", "Q19", "Q22")])

# 想象 (FS): 测量个体对虚构人物感同身受的反应 [cite: 2]
df_clean$FS <- rowSums(df_clean[, c("Q3", "Q5", "Q10", "Q12", "Q17", "Q20")])

# 共情关注 (EC): 测量对他人不幸的同情和关注 (他人取向) [cite: 2]
df_clean$EC <- rowSums(df_clean[, c("Q1", "Q2", "Q7", "Q11", "Q14", "Q16")])

# 个人忧伤 (PD): 测量紧张人际场景中的焦虑与不适 (自我取向) [cite: 2]
df_clean$PD <- rowSums(df_clean[, c("Q4", "Q8", "Q13", "Q18", "Q21")])

# 综合得分计算 [cite: 2]
df_clean$Cognitive <- df_clean$PT + df_clean$FS  # 认知共情
df_clean$Emotional <- df_clean$EC + df_clean$PD  # 情绪共情
df_clean$Total_IRI <- rowSums(df_clean[, items]) # 总共情能力

# 4. 共同方法偏差 (CMV) 检验：Harman 单因子法
# 检验标准：第一个因子解释的变异量应低于 40%
harman_test <- principal(df_clean[, items], nfactors = 1, rotate = "none")
cmv_result <- harman_test$Vaccounted["Proportion Var",] * 100
cat("\n--- 共同方法偏差 (CMV) 检验 ---\n")
cat(sprintf("Harman单因子方差解释率: %.2f%%\n", cmv_result))

# 5. 各维度内部一致性信度 (Cronbach's Alpha) [cite: 2]
cat("\n--- 内部一致性信度 (Alpha) ---\n")
dim_list <- list(
  PT = c("Q6", "Q9", "Q15", "Q19", "Q22"),
  FS = c("Q3", "Q5", "Q10", "Q12", "Q17", "Q20"),
  EC = c("Q1", "Q2", "Q7", "Q11", "Q14", "Q16"),
  PD = c("Q4", "Q8", "Q13", "Q18", "Q21")
)

# 计算各维度α
alpha_results <- sapply(dim_list, function(x) psych::alpha(df_clean[, x])$total$raw_alpha)

# 计算总量表α（所有题项）
total_alpha <- psych::alpha(df_clean[, items])$total$raw_alpha

# 合并结果
alpha_results <- c(alpha_results, Total_IRI = total_alpha)

# 输出
print(round(alpha_results, 3))


# 6. 维度相关性分析
cat("\n--- 维度相关性矩阵 (Pearson) ---\n")
cor_matrix <- rcorr(as.matrix(df_clean[, c("PT", "FS", "EC", "PD")]), type = "pearson")
cat("相关系数 (r):\n")
print(round(cor_matrix$r, 3))
cat("显著性水平 (p):\n")
print(round(cor_matrix$P, 3))

# 运行相关分析
cor_results <- rcorr(as.matrix(df_clean[, c("PT", "FS", "EC", "PD")]), type = "pearson")

# 为下一步分析做准备
iri_processed <- df_clean |>
  select('participant', 'PT', 'FS', 'EC', 'PD', 'Cognitive', 'Emotional', 'Total_IRI') 
iri_processed$gender <- demo_df$gender
iri_processed <-  iri_processed |>
  rename(IRI_total = Total_IRI)
