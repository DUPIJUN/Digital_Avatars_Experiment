import pandas as pd
import glob
import os

# --- 1. 配置路径 (使用绝对路径适配，防止相对路径报错) ---
# 获取当前脚本所在的文件夹路径
script_dir = os.path.dirname(os.path.abspath(__file__))
# 向上退一级到项目根目录，再进入数据文件夹
base_dir = os.path.dirname(script_dir) 
input_folder = os.path.join(base_dir, 'data_raw')      
output_folder = os.path.join(base_dir, 'data_cleaned') 
output_file = os.path.join(output_folder, 'merged_data.csv')

def start_cleaning():
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 获取所有CSV文件
    all_files = glob.glob(os.path.join(input_folder, "*.csv"))
    
    if not all_files:
        print(f"❌ 错误：在路径 {os.path.abspath(input_folder)} 下没找到任何 CSV 文件！")
        print("请检查你的原始数据是否真的放在了这个文件夹里。")
        return

    print(f"🚀 启动清洗，共检测到 {len(all_files)} 个文件...")

    combined_data = []

    for file in all_files:
        try:
            # 1. 读取数据
            df = pd.read_csv(file)
            
            # 2. 锁定正式实验行 (根据你提供的样本，trials.thisIndex 在 0-23 之间是有效行)
            # 先转数值，防止列里有引号导致的解析失败
            df['trials.thisIndex'] = pd.to_numeric(df['trials.thisIndex'], errors='coerce')
            df_clean = df[df['trials.thisIndex'].between(0, 23)].copy()

            if df_clean.empty:
                print(f"⚠️ 跳过文件 {os.path.basename(file)}: 没有找到 0-23 范围内的有效实验行")
                continue

            # 3. 提取并重命名列
            mapping = {
                'participant': 'participant',
                'gender': 'gender',
                'AVATAR_AGE': 'AVATAR_AGE',
                'AVATAR_SEX': 'AVATAR_SEX',
                'INTENSITY': 'INTENSITY',
                'trials.pain_slider.response': 'pain_score',
                'trials.help_slider.response': 'help_score',
                'trials.pain_slider.rt': 'pain_rt',
                'trials.help_slider.rt': 'help_rt'
            }
            
            existing_cols = [c for c in mapping.keys() if c in df_clean.columns]
            df_final = df_clean[existing_cols].copy()
            df_final.rename(columns=mapping, inplace=True)

            # 4. 强制数值重算（处理潜在的引号问题）
            numeric_targets = ['pain_score', 'help_score', 'pain_rt', 'help_rt']
            for col in numeric_targets:
                if col in df_final.columns:
                    # 先转字符串，去掉可能存在的引号，再转回浮点数
                    df_final[col] = pd.to_numeric(
                        df_final[col].astype(str).str.replace("'", "").str.replace("`", ""), 
                        errors='coerce'
                    )

            # 5. 清理 ID 和分类列（转为干净的字符串）
            id_targets = ['participant', 'gender', 'AVATAR_AGE', 'AVATAR_SEX', 'INTENSITY']
            for col in id_targets:
                if col in df_final.columns:
                    df_final[col] = df_final[col].astype(str).str.replace("'", "").str.strip()

            combined_data.append(df_final)
            print(f"✅ 已处理: {os.path.basename(file)} ({len(df_final)} 行)")

        except Exception as e:
            print(f"❌ 处理文件 {file} 时出错: {e}")

    # --- 合并与保存 ---
    if combined_data:
        result_df = pd.concat(combined_data, ignore_index=True)
        # 保存，不使用引代码
        result_df.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"\n✨ 清洗完成！")
        print(f"总计合并：{len(result_df)} 行数据")
        print(f"结果路径：{output_file}")
    else:
        print("\n❌ 最终没有可合并的数据，请检查原始数据格式。")

if __name__ == "__main__":
    start_cleaning()