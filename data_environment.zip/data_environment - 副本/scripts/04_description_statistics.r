library(dplyr)

# 计算 4 个实验条件下（2年龄 x 2性别）的描述统计
experiment_stats <- subject_agg_data %>%
  group_by(AVATAR_AGE, AVATAR_SEX) %>%
  summarise(
    # 疼痛感知的 M 与 SD
    Pain_M = mean(m_pain, na.rm = TRUE),
    Pain_SD = sd(m_pain, na.rm = TRUE),
    # 帮助意愿的 M 与 SD
    Help_M = mean(m_help, na.rm = TRUE),
    Help_SD = sd(m_help, na.rm = TRUE),
    # 样本量
    Count = n(),
    .groups = "drop"
  )

print(experiment_stats)