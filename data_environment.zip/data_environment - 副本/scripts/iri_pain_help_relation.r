# 如果没有安装 gtools，请先运行: install.packages("gtools")
library(gtools)

# 1. 确保数据已经合并（使用之前合并好的 final_cor_data）
# 如果之前没跑成功，请确保这一步的数据是 72 行（每人一行）
# final_cor_data <- subject_avg_performance %>% left_join(iri_scores_with_id, by = "participant")

# 2. 计算相关和显著性
res_cor <- Hmisc::rcorr(as.matrix(final_cor_data), type = "pearson")

# 3. 提取相关系数 r 和 P 值
r_val <- res_cor$r
p_val <- res_cor$P

# 4. 将 P 值转换为星号标注
# *** < 0.001, ** < 0.01, * < 0.05
mystars <- gtools::stars.pval(p_val)

# 5. 拼接系数与星号并格式化输出
R_with_stars <- matrix(paste(format(round(r_val, 3), nsmall = 3), mystars), 
                       ncol = ncol(r_val))
diag(R_with_stars) <- "-" # 对角线设为横杠
rownames(R_with_stars) <- colnames(r_val)
colnames(R_with_stars) <- colnames(r_val)

# 6. 最终输出结果
cat("\n--- 实验变量与 IRI 相关性矩阵 (含星号标注) ---\n")
print(as.data.frame(R_with_stars))

# 1. 检查参与相关分析的总行数
nrow(final_cor_data) 

# 2. 检查是否有重复的 ID
length(unique(final_cor_data$participant)) 

# 3. 看看 IRI 的分数是否有异常（比如所有人分都差不多）
summary(iri_scores)