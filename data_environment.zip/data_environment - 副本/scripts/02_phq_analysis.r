# 加载必要包
library(tidyverse)
library(psych)
library(readxl)

# 1. 读取数据（假设你的 PHQ 数据在 Excel 中）
phq_data <- read_excel("data_raw/PHQ-9_origin.xlsx")

# 2. 信度分析 (Cronbach's alpha)
# 提取 P1 到 P9 这 9 个题目列
phq_items <- phq_data |> select('P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7', 'P8', 'P9')
phq_rel <- psych::alpha(phq_items)

message("PHQ-9 量表信度系数 (Alpha):")
print(phq_rel$total$std.alpha)

# 3. 描述统计（均值、标准差、检出率）
# 假设总分列名为“总分”
message("\nPHQ-9 总分描述统计:")
print(describe(phq_data$P_TOTAL))

# 4. 抑郁程度分级统计（符合医学/心理学论文汇报习惯）
phq_summary <- phq_data |>
  mutate(level = case_when(
    P_TOTAL <= 4 ~ "无抑郁",
    P_TOTAL <= 9 ~ "轻度抑郁",
    P_TOTAL <= 14 ~ "中度抑郁",
    P_TOTAL <= 19 ~ "中重度抑郁",
    TRUE ~ "重度抑郁"
  )) %>%
  group_by(level) %>%
  summarise(n = n(), percentage = n() / nrow(phq_data) * 100)

# 计算不同得分区间的人数（这就是你的筛查证据）
phq_report <- data.frame(Score = phq_data$P_TOTAL) %>%
  mutate(Category = case_when(
    Score <= 4 ~ "无抑郁 (0-4分)",
    Score <= 9 ~ "轻度抑郁 (5-9分)",
    TRUE ~ "中度及以上 (>10分)"
  )) %>%
  group_by(Category) %>%
  summarise(人数 = n(), 占比 = paste0(round(n()/72*100, 2), "%"))

print(phq_report)

print(phq_summary)
